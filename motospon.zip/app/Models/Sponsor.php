<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class Sponsor extends Model
{
    use HasFactory, Sluggable;

    // Menghubungkan dengan Model User
    public function users()
    {
        return $this->belongsToMany(User::class)
            ->withPivot('is_active', 'is_completed')
            ->withTimestamps();
    }

    // protected $fillable = ['title','excerpt','body'];
    protected $guarded = ['id'];

    public function scopeFilter($query, array $filters)
    {
        $query->when($filters['search'] ?? false, function ($query, $search) {
            return $query->where('title', 'like', '%' . $search . '%')
                ->orWhere('body', 'like', '%' . $search . '%');
        });

        $query->when(
            $filters['author'] ?? false,
            fn ($query, $author) =>
            $query->whereHas(
                'author',
                fn ($query) =>
                $query->where('username', $author)
            )
        );
    }

    public function author()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

    // Menambahkan dua kolom baru untuk status aktif dan selesai
    protected $fillable = [
        'title', 'excerpt', 'body', 'user_id', 'image', 'published_at', 'created_at', 
    ];
}
