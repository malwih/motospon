<footer class="mx-auto bg-gray-100 w-full max-w-container px-4 sm:px-6 lg:px-8">
    <div class="border-t border-slate-900/20 py-10">
            <a href="/">
				<img class="mx-auto h-10 w-auto text-slate-900" src="../storage/img/logo.png" height="250" width="300" />
			</a>
        <p class="mt-5 text-center text-sm leading-6 text-slate-500">© 2023 Le France Courses. All rights reserved.</p>
    </div>
</footer>