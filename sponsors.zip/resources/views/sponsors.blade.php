@extends('layouts.main')

@section('container')
<div class="bg-gradient-to-tr from-orange-300 to-orange-200 flex justify-center items-center">
    <h2 class="flex justify-center text-3xl font-bold text-orange-500 py-5">Sponsorship</h2>
</div>

<div class="min-h-screen bg-gradient-to-tr from-gray-300 to-gray-200 flex justify-center items-center px-4 py-10">
    <div class="md:px-4 md:grid md:grid-cols-2 lg:grid-cols-3 gap-5 space-y-4 md:space-y-0">
        @foreach ($sponsors as $sponsor)
        <div class="max-w-sm bg-white px-6 pt-6 pb-2 rounded-xl shadow-lg transform hover:scale-105 transition duration-500">
            <div class="relative">
                <img class="w-full h-48 object-cover rounded-xl" src="{{ asset('storage/' . $sponsor->image) }}" alt="{{ $sponsor->title }}">
                <p class="absolute top-0 left-0 bg-yellow-300 text-gray-800 font-semibold py-1 px-3 rounded-br-lg rounded-tl-lg">
                    {{ $sponsor->price }}
                </p>
            </div>
            <h1 class="mt-4 text-gray-800 text-2xl font-bold cursor-pointer">{{ $sponsor->title }}</h1>
            <div class="my-4 space-y-2">
                <div class="flex space-x-1 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p class="text-sm text-gray-700">{{ $sponsor->term }}</p>
                </div>
                <div class="flex space-x-1 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M16 4v12l-4-2-4 2V4M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p class="text-sm text-gray-700">{{ $sponsor->schedule }}</p>
                </div>
            </div>
            <a href="/sponsors/{{ $sponsor->slug }}">
                <button class="mt-4 w-full text-white bg-indigo-600 hover:bg-indigo-700 py-2 rounded-xl shadow-lg transition">Detail</button>
            </a>
        </div>
        @endforeach
    </div>
</div>
@endsection
