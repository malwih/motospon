<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Sponsor;
use App\Models\Category;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\SponsorController;
use App\Http\Controllers\GoogleController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\MyProfileController;
use App\Http\Controllers\AdminCategoryController;
use App\Http\Controllers\NewsDashboardController;
use App\Http\Controllers\DashboardSponsorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home', [
        "title" => "Home",
        "active" => "home"
    ]);
});

Route::get('/sponsors', [SponsorController::class, 'index']);
Route::get('/news', [NewsController::class, 'index']);
Route::get('/sponsors/{sponsor:slug}', [SponsorController::class, 'show']);
Route::get('/news/{news:slug}', [NewsController::class, 'show']);

Route::get('/categories', function () {
    return view('categories', [
        'title' => 'Sponsor Categories',
        'categories' => Category::all()
    ]);
});

Route::get('/login', [LoginController::class, 'index'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout']);

Route::get('/register', [RegisterController::class, 'index'])->middleware('guest');
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/dashboard', function () {
    return view('dashboard.index');
})->middleware('auth');

Route::get('/dashboard/sponsors/checkSlug', [DashboardSponsorController::class, 'checkSlug'])
    ->middleware('auth');

// Modifikasi tampilan dashboard
Route::middleware(['auth'])->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardSponsorController::class, 'dashboard'])->name('dashboard');
    // Sponsors
    Route::get('/sponsor/{id}/take', [SponsorController::class, 'take'])->name('sponsor.take');
    Route::get('/sponsor/{id}/complete', [SponsorController::class, 'complete'])->name('sponsor.complete');

    Route::get('/dashboard/addsponsor', [DashboardSponsorController::class, 'addsponsor'])->name('addsponsor');
    Route::post('/dashboard/addsponsor', [DashboardSponsorController::class, 'storeSponsor'])->name('sponsors.take');
    Route::post('/sponsors/take', [DashboardSponsorController::class, 'takeSponsor'])->name('sponsors.take');
    Route::post('/dashboard/addsponsor', [DashboardSponsorController::class, 'takeSponsor'])->name('sponsors.take');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard/myprofile', [MyProfileController::class, 'index'])->name('myprofile.index');
    Route::get('/dashboard/editprofile', [MyProfileController::class, 'edit'])->name('editprofile.edit');
    Route::put('/dashboard/myprofile', [MyProfileController::class, 'update'])->name('editprofile.update');
    // Route PDF Report
    Route::get('/dashboard/news/pdf', [NewsDashboardController::class, 'pdfReport'])->name('pdfReport');
    // Route Student List
    Route::get('/dashboard/student', [MyProfileController::class, 'studentList'])->name('studentList');
    Route::delete('/dashboard/student/{userId}', [MyProfileController::class, 'deleteUser'])->name('deleteUser');
    Route::get('/dashboard/student/pdfstudent', [MyProfileController::class, 'pdfStudent'])->name('pdfStudent');
});



Route::resource('/dashboard/sponsors', DashboardSponsorController::class)
    ->middleware('auth');

Route::resource('/dashboard/news', NewsDashboardController::class)
    ->middleware('auth');



Route::resource('/dashboard/categories', AdminCategoryController::class)->except('show')->middleware('admin');

Route::get('auth/google', [GoogleController::class, 'redirectToGoogle']);
Route::get('auth/google/callback', [GoogleController::class, 'handleGoogleCallback']);

Route::get('/choose-account-type', [GoogleController::class, 'chooseAccountType'])->name('choose.account.type');
Route::post('/choose-account-type', [GoogleController::class, 'storeAccountType'])->name('store.account.type');

Route::get('/dashboard', [DashboardSponsorController::class, 'index'])
    ->middleware(['auth', 'account.type']);

